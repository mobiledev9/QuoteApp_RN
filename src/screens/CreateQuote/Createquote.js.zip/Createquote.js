import React, {Component, createRef} from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  ImageBackground,
  PanResponder,
  Animated,
  FlatList,
  Pressable,
  SafeAreaView,
  Platform,
  TouchableNativeFeedback,
  Share,
} from 'react-native';
import Popover from 'react-native-popover-view';
import FastImage from 'react-native-fast-image';
import Tooltip from 'react-native-walkthrough-tooltip';
import LinearGradient from 'react-native-linear-gradient';
import {CameraRoll} from '@react-native-camera-roll/camera-roll';
import ViewShot from 'react-native-view-shot';
import tinycolor from 'tinycolor2';
import {openDatabase} from 'react-native-sqlite-storage';
import {
  ColorMatrix,
  concatColorMatrices,
  contrast,
  saturate,
  brightness,
  temperature,
  hueRotate,
  grayscale,
  tint,
  sepia,
} from 'react-native-color-matrix-image-filters';
import CustomHeader from '../../components/CreateQuote/CustomHeader';
import {CustomColors} from '../../theme/CustomColors';
import {Img} from '../../theme/Img';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from '../../theme/layout';
import {Onboardingstyles} from '../OnBoarding/Onboardingstyles';
import {tabs} from '../../theme/Colors';
import ColorsSheet from '../../components/ColorsSheet/ColorsSheet';
import TextEditor from '../../components/TextEditor/TextEditor';
import TextEditorSheet from '../../components/TextEditorSheet/TextEditorSheet';
import ColorSlider from '../../components/ColorSlider/ColorSlider';
import FontSheet from '../../components/FontSheet/FontSheet';
import EffectModal from '../../components/EffectModal/EffectModal';
import ShadowModal from '../../components/ShadowModal/ShadowModal';
import StoreModal from '../../components/StoreModal/StoreModal';
import TabButton from '../../components/TabButton/TabButton';

var db = openDatabase({
  name: 'example.db',
  createFromLocation: 1,
});

class Createquote extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showPop: false,
      isIndex: 0,
      oldColor: '',
      showPicker: false,
      editorPosition: {x: 0, y: 0},
      text: '',
      pan: new Animated.ValueXY(),
      deg: 0,
      edittext: '',
      newheight: 50,
      newwidth: 80,
      isResize: false,

      isOpenColorSheet: false,
      bgColor: null,
      bgImage: null,
      gradiantBgImage: null,
      isOpenTextEditor: false,
      quoteText: '',
      quoteSize: hp(2),
      quoteAlign: 'center',
      quoteLineSpace: 20,
      quoteLetterSpace: 0,
      quoteTextColor: CustomColors.white,
      quoteFontFamily: 'Poppins-Regular',
      quoteShadowColor: 'transparent',
      quoteShadowRadius: 0,
      quoteShadowOffsetWidth: 0,
      quoteShadowOffsetHeight: 0,

      blurOpacity: 0,
      brightness: 1,
      saturation: 1,
      contrast: 1,
      temperature: 0,
      hue: 0,
      grayscale: -1,
      tint: 0,
      sepia: 0,

      isQuoteBox: false,
      isColorModal: false,
      isFontModal: false,
      isShadowModal: false,
      isSaveModal: false,

      wallpapers: [],
    };

    this.richText = createRef();
    this.viewRef = createRef();
    this.sliderHuePicker = createRef();
    this.pickerRef = createRef();
    this.shadowRef = createRef();
    this.otherRef = createRef();
    this.saveRef = createRef();
  }
  componentDidMount() {
    this.getTemplates();
  }

  UNSAFE_componentWillMount() {
    this._val = {x: 0, y: 0};
    this.state.pan.addListener(value => (this._val = value));
    this.panResponder = PanResponder.create({
      onStartShouldSetPanResponder: (e, gesture) => true,
      onPanResponderMove: Animated.event([
        null,
        {dx: this.state.pan.x, dy: this.state.pan.y},
      ]),
    });

    this.newResponder = PanResponder.create({
      onMoveShouldSetPanResponder: () => this.state.isResize,
      onPanResponderMove: (event, gestureState) => {
        this.setState(state => ({
          newheight: this.state.newheight + gestureState.dy,
          newwidth: this.state.newwidth + gestureState.dx,
        }));
      },
      onPanResponderRelease: () => this.setState({isResize: false}),
    });
  }

  getTemplates = async () => {
    var data = [];
    await db.transaction(tx => {
      tx.executeSql('SELECT * FROM images', [], (tx, results) => {
        var len = results.rows.length;

        for (var i = 0; i < len; i++) {
          data = [...data, results.rows.item(i)];
        }
        this.setState({wallpapers: data});
      });
    });
  };

  onShare = async () => {
    try {
      const result = await Share.share({
        message:
          'React Native | A framework for building native apps using React',
      });
      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
        } else {
          // shared
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
      }
    } catch (error) {
      Alert.alert(error.message);
    }
  };

  changeColor = (colorHsvOrRgb, resType) => {
    if (resType === 'end') {
      this.setState({
        quoteTextColor: tinycolor(colorHsvOrRgb).toHexString(),
      });
    }
  };

  render() {
    return (
      <SafeAreaView style={{flex: 1}}>
        <View style={Onboardingstyles.mainbg}>
          <CustomHeader
            saveRef={this.saveRef}
            onSave={() => this.setState({isSaveModal: true})}
          />

          <ViewShot
            ref={this.viewRef}
            options={{fileName: 'img', format: 'jpg', quality: 0.9}}>
            <View
              style={{
                backgroundColor: CustomColors.bottomtabbg,
                height: Platform.OS == 'android' ? hp(68) : hp(60),
                width: wp(100),
              }}>
              {this.state.bgColor && typeof this.state.bgColor == 'object' ? (
                <LinearGradient
                  colors={this.state.bgColor}
                  style={{
                    height: '100%',
                    width: '100%',
                  }}></LinearGradient>
              ) : this.state.bgColor &&
                typeof this.state.bgColor == 'string' ? (
                <View
                  style={{
                    height: '100%',
                    width: '100%',
                    backgroundColor: this.state.bgColor,
                  }}></View>
              ) : (
                <TouchableNativeFeedback
                  onPress={() => this.setState({isQuoteBox: false})}>
                  <ColorMatrix
                    matrix={concatColorMatrices(
                      saturate(this.state.saturation),
                      contrast(this.state.contrast),
                      brightness(this.state.brightness),
                      temperature(this.state.temperature),
                      hueRotate(this.state.hue),
                      tint(this.state.tint),
                      sepia(this.state.sepia),
                      grayscale(this.state.grayscale),
                    )}>
                    <ImageBackground
                      resizeMode="stretch"
                      blurRadius={this.state.blurOpacity}
                      source={
                        this.state.gradiantBgImage
                          ? {uri: this.state.gradiantBgImage}
                          : this.state.bgImage
                          ? {uri: this.state.bgImage}
                          : Img.roadsample
                      }
                      style={{
                        height: '100%',
                        width: '100%',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}>
                      {this.state.quoteText && (
                        <View
                          style={{
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}>
                          <Animated.View
                            {...this.panResponder.panHandlers}
                            style={{
                              borderWidth: this.state.isQuoteBox ? 1 : 0,
                              borderColor: CustomColors.white,
                              width: this.state.newwidth,
                              height: this.state.newheight,
                              marginHorizontal: wp(5),
                              transform: [
                                ...this.state.pan.getTranslateTransform(),
                                ...[{rotate: `${this.state.deg}deg`}],
                              ],
                            }}>
                            <View
                              style={{
                                width: this.state.newwidth,
                                height: this.state.newheight,
                                justifyContent: 'center',
                              }}
                              {...this.newResponder.panHandlers}>
                              <Text
                                onPress={() =>
                                  this.setState({isQuoteBox: true})
                                }
                                style={{
                                  color: this.state.quoteTextColor,
                                  textAlignVertical: 'center',
                                  margin: wp(2),
                                  fontSize: this.state.quoteSize,
                                  textAlign: this.state.quoteAlign,
                                  letterSpacing: this.state.quoteLetterSpace,
                                  lineHeight: this.state.quoteLineSpace,
                                  fontFamily: this.state.quoteFontFamily,
                                  textShadowColor: this.state.quoteShadowColor,
                                  textShadowRadius:
                                    this.state.quoteShadowRadius,
                                  textShadowOffset: {
                                    height: -this.state.quoteShadowOffsetHeight,
                                    width: this.state.quoteShadowOffsetWidth,
                                  },
                                }}>
                                {this.state.quoteText}
                              </Text>
                              {this.state.isQuoteBox && (
                                <>
                                  <TouchableOpacity
                                    onPress={() => {
                                      this.setState({deg: this.state.deg + 90});
                                    }}
                                    style={{
                                      position: 'absolute',
                                      top: -20,
                                      alignSelf: 'center',
                                    }}>
                                    <Image
                                      source={Img.undo}
                                      style={{height: hp(3), width: hp(3)}}
                                    />
                                  </TouchableOpacity>
                                  <TouchableOpacity
                                    onPress={() =>
                                      this.setState({isIndex: 0, quoteText: ''})
                                    }
                                    style={{
                                      position: 'absolute',
                                      top: -10,
                                      right: -10,
                                    }}>
                                    <Image
                                      resizeMode="contain"
                                      source={Img.cancel}
                                      style={{height: hp(3), width: hp(3)}}
                                    />
                                  </TouchableOpacity>
                                  <TouchableOpacity
                                    onLongPress={() => {
                                      this.setState({
                                        isResize: true,
                                      });
                                    }}
                                    style={{
                                      position: 'absolute',
                                      right: -10,
                                      bottom: -10,
                                      // alignSelf: 'flex-end',

                                      // marginTop:this.state.newheight-this.state.newheight+30,
                                      // marginLeft: this.state.newwidth,
                                    }}>
                                    <Image
                                      source={Img.arrow}
                                      style={{height: hp(3), width: hp(3)}}
                                    />
                                  </TouchableOpacity>
                                </>
                              )}
                            </View>
                          </Animated.View>
                        </View>
                      )}
                    </ImageBackground>
                  </ColorMatrix>
                </TouchableNativeFeedback>
              )}
            </View>
          </ViewShot>
          {this.state.isIndex == 0 && (
            <View
              style={{
                backgroundColor: CustomColors.white,
                elevation: 5,
                width: wp(90),
                alignSelf: 'center',
                borderRadius: 10,
                marginTop: hp(2),
                padding: hp(1),
                alignItems: 'center',
                flexDirection: 'row',
              }}>
              <View style={{flexDirection: 'row'}}>
                <TouchableOpacity
                  onPress={() => {
                    this.setState({
                      isOpenColorSheet: true,
                    });
                  }}>
                  <Image
                    resizeMode="contain"
                    source={Img.colorpicker}
                    style={{height: hp(6), width: hp(6), marginRight: wp(2.5)}}
                  />
                </TouchableOpacity>

                <View
                  style={{
                    borderRightWidth: 1,
                    borderColor: CustomColors.bordercolor,
                  }}
                />
                <FlatList
                  data={this.state.wallpapers}
                  keyExtractor={item => item.id}
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  renderItem={({item}) => (
                    <Pressable
                      onPress={() =>
                        this.setState({
                          bgImage: 'data:image/png;base64,' + item.data,
                          gradiantBgImage: null,
                          bgColor: null,
                        })
                      }>
                      <FastImage
                        style={{
                          height: hp(6),
                          width: hp(6),
                          marginLeft: wp(2.5),
                          borderRadius: 10,
                        }}
                        source={{
                          uri: 'data:image/png;base64,' + item.data,
                          priority: FastImage.priority.normal,
                        }}
                        resizeMode={FastImage.resizeMode.cover}
                      />
                    </Pressable>
                  )}
                />
              </View>
            </View>
          )}
          {this.state.isIndex == 2 && (
            <View
              style={{
                backgroundColor: CustomColors.white,
                elevation: 5,
                width: wp(90),
                alignSelf: 'center',
                borderRadius: 10,
                marginTop: hp(2),
                padding: hp(1),
              }}>
              <TextEditorSheet
                isIncrease={() =>
                  this.setState({quoteSize: this.state.quoteSize + 2})
                }
                isDecrease={() =>
                  this.setState({quoteSize: this.state.quoteSize - 2})
                }
                isLeft={() => this.setState({quoteAlign: 'left'})}
                isCenter={() => this.setState({quoteAlign: 'center'})}
                isRight={() => this.setState({quoteAlign: 'right'})}
                isLineSpaceD={() =>
                  this.setState({
                    quoteLineSpace: this.state.quoteLineSpace - 5,
                  })
                }
                isLineSpaceI={() =>
                  this.setState({
                    quoteLineSpace: this.state.quoteLineSpace + 5,
                  })
                }
                isLetterSpaceD={() =>
                  this.setState({
                    quoteLetterSpace: this.state.quoteLetterSpace - 1,
                  })
                }
                isLetterSpaceI={() =>
                  this.setState({
                    quoteLetterSpace: this.state.quoteLetterSpace + 1,
                  })
                }
              />
            </View>
          )}
          {this.state.isIndex == 5 && (
            <EffectModal
              onBlur={val => this.setState({blurOpacity: val})}
              onBrightness={val => this.setState({brightness: val})}
              onContrast={val => this.setState({contrast: val == 0 ? 1 : val})}
              onSaturation={val =>
                this.setState({saturation: val == 0 ? 1 : val})
              }
              onTemperature={val => this.setState({temperature: val})}
              onHue={val => this.setState({hue: val})}
              onVintage={val => this.setState({grayscale: val})}
              onExposure={val => this.setState({tint: val})}
              onColorize={val => this.setState({sepia: val})}
              onxProcess={val => this.setState({night: val})}
            />
          )}

          <View
            style={{
              width: wp(100),
              flexDirection: 'row',
              alignItems: 'center',
              backgroundColor: CustomColors.bottomtabbg,
              height: Platform.OS == 'android' ? hp(12) : hp(10),
              position: 'absolute',
              bottom: hp(0),
            }}>
            <ScrollView
              showsHorizontalScrollIndicator={false}
              horizontal={true}>
              <TabButton
                onPress={() =>
                  this.setState({
                    showPop: true,
                    isIndex: 0,
                  })
                }
                title="Background"
                icon={this.state.isIndex == 0 ? Img.blackgallery : Img.gallery}
                dotColor={this.state.isIndex == 0 ? CustomColors.black : ''}
              />
              <TabButton
                onPress={() =>
                  this.setState({
                    showPop: true,
                    isIndex: 1,
                  })
                }
                title="Text"
                icon={this.state.isIndex == 1 ? Img.textblack : Img.text}
                dotColor={this.state.isIndex == 1 ? CustomColors.black : ''}
              />
              <TabButton
                onPress={() =>
                  this.setState({
                    showPop: true,
                    isIndex: 2,
                  })
                }
                title="Property"
                icon={
                  this.state.isIndex == 2 ? Img.propertyblack : Img.property
                }
                dotColor={this.state.isIndex == 2 ? CustomColors.black : ''}
              />
              <Tooltip
                isVisible={this.state.isFontModal}
                content={
                  <FontSheet
                    onSelect={font => this.setState({quoteFontFamily: font})}
                  />
                }
                placement="top"
                onClose={() => this.setState({isFontModal: false})}>
                <TabButton
                  onPress={() =>
                    this.setState({
                      showPop: true,
                      isIndex: 3,
                      isFontModal: true,
                    })
                  }
                  title="Font"
                  icon={this.state.isIndex == 3 ? Img.fontblack : Img.font}
                  dotColor={this.state.isIndex == 3 ? CustomColors.black : ''}
                />
              </Tooltip>

              <TabButton
                onPress={() =>
                  this.setState({
                    showPop: true,
                    isIndex: 4,
                    isColorModal: true,
                  })
                }
                title="Color"
                icon={this.state.isIndex == 4 ? Img.colorblack : Img.color}
                dotColor={this.state.isIndex == 4 ? CustomColors.black : ''}
              />
              <TabButton
                onPress={() =>
                  this.setState({
                    showPop: true,
                    isIndex: 5,
                  })
                }
                title="Effect"
                icon={this.state.isIndex == 5 ? Img.effectblack : Img.effect}
                dotColor={this.state.isIndex == 5 ? CustomColors.black : ''}
              />
              <TabButton
                onPress={() =>
                  this.setState({
                    showPop: true,
                    isIndex: 6,
                    isShadowModal: true,
                  })
                }
                title="Shadow"
                icon={this.state.isIndex == 6 ? Img.shadowblack : Img.shadow}
                dotColor={this.state.isIndex == 6 ? CustomColors.black : ''}
              />

              {/* {tabs.map((item, index) => (
                <TouchableOpacity
                  ref={
                    index == 4
                      ? this.pickerRef
                      : index == 3
                      ? this.fontPickerRef
                      : index == 6
                      ? this.shadowRef
                      : this.otherRef
                  }
                  onPress={() => {
                    this.setState({
                      showPop: true,
                      isIndex: index,
                    });
                    index == 4 && this.setState({isColorModal: true});
                    index == 3 && this.setState({isFontModal: true});
                    index == 6 && this.setState({isShadowModal: true});
                  }}
                  style={{
                    marginHorizontal: wp(5),
                    alignItems: 'center',
                  }}>
                  {this.state.isIndex === index ? (
                    <View style={{alignItems: 'center'}}>
                      <View
                        style={{
                          height: hp(0.8),
                          width: hp(0.8),
                          backgroundColor: CustomColors.black,
                          borderRadius: 100,
                          marginBottom: hp(0.8),
                        }}></View>
                      <Image
                        resizeMode="contain"
                        source={item.imgblack}
                        style={{height: hp(5), width: hp(5)}}
                      />
                    </View>
                  ) : (
                    <View style={{alignItems: 'center'}}>
                      <View
                        style={{
                          height: hp(0.8),
                          width: hp(0.8),
                          backgroundColor: CustomColors.bottomtabbg,
                          borderRadius: 100,
                          marginBottom: hp(0.8),
                        }}></View>
                      <Image
                        resizeMode="contain"
                        source={item.img}
                        style={{height: hp(5), width: hp(5)}}
                      />
                    </View>
                  )}
                  <Text
                    style={{
                      fontFamily: 'Poppins-Regular',
                      color: CustomColors.black,
                      fontSize: hp(1.5),
                      marginTop: hp(0.5),
                    }}>
                    {item.title}
                  </Text>
                </TouchableOpacity>
              ))} */}
            </ScrollView>
          </View>

          {/* Models and Popover Modals */}
          <ColorsSheet
            isOpen={this.state.isOpenColorSheet}
            isClose={() => {
              this.setState({isOpenColorSheet: false});
              this.viewRef.current
                .capture()
                .then(uri => {
                  this.setState({gradiantBgImage: uri, bgColor: null});
                  console.log('do something with ', uri);
                })
                .catch(err => console.log('err:', err));
            }}
            onChangeColor={item =>
              this.setState({
                bgColor: item,
              })
            }
          />

          <TextEditor
            isOpen={this.state.isIndex == 1}
            isClose={() => this.setState({isIndex: 0, quoteText: ''})}
            isDone={() => this.setState({isIndex: 0, isQuoteBox: true})}
            value={this.state.quoteText}
            onChangeText={text => this.setState({quoteText: text})}
          />

          <Popover
            from={this.pickerRef}
            isVisible={this.state.isColorModal}
            popoverStyle={{borderRadius: 10}}
            backgroundStyle={{opacity: 0}}
            onRequestClose={() => this.setState({isColorModal: false})}>
            <ColorSlider
              onChangeColor={color => {
                const picked = tinycolor(color);
                const Hexcolor = picked.toHexString();
                this.setState({
                  quoteTextColor: Hexcolor,
                });
              }}
            />
          </Popover>

          <Popover
            from={this.shadowRef}
            isVisible={this.state.isShadowModal}
            backgroundStyle={{opacity: 0}}
            popoverStyle={{borderRadius: 10}}
            onRequestClose={() => this.setState({isShadowModal: false})}>
            <ShadowModal
              xValue={this.state.quoteShadowOffsetWidth}
              yValue={this.state.quoteShadowOffsetHeight}
              bValue={this.state.quoteShadowRadius}
              onBlur={val =>
                this.setState({
                  quoteShadowRadius: Number(val.toFixed(2)),
                  quoteShadowColor: this.state.quoteShadowColor,
                })
              }
              onLeftRight={val =>
                this.setState({
                  quoteShadowOffsetWidth: Number(val.toFixed(2)),
                  quoteShadowColor: this.state.quoteShadowColor,
                })
              }
              onUpDown={val =>
                this.setState({
                  quoteShadowOffsetHeight: Number(val.toFixed(2)),
                  quoteShadowColor: this.state.quoteShadowColor,
                })
              }
              onChangeColor={color => {
                const picked = tinycolor(color);
                const Hexcolor = picked.toHexString();
                this.setState({
                  quoteShadowColor: Hexcolor,
                });
              }}
            />
          </Popover>

          <Popover
            from={this.saveRef}
            isVisible={this.state.isSaveModal}
            popoverStyle={{borderRadius: 10, marginTop: hp(2)}}
            arrowSize={{height: 0, width: 0}}
            onRequestClose={() => this.setState({isSaveModal: false})}>
            <StoreModal
              isShare={() => this.onShare()}
              isSaveGallery={() => {
                this.viewRef.current.capture().then(uri => {
                  console.log('do something with ', uri);
                  CameraRoll.saveToCameraRoll(uri)
                    .then(
                      this.setState({isSaveModal: false}),
                      alert('Photo saved to Gallery'),
                    )
                    .catch(err => console.log('err:', err));
                });
              }}
            />
          </Popover>

          {/* Models and Popover Modals */}
        </View>
      </SafeAreaView>
    );
  }
}

export default Createquote;
